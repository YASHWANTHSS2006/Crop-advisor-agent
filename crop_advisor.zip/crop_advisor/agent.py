import anthropic

from tools import TOOL_FUNCTIONS, TOOL_SCHEMAS

client = anthropic.Anthropic()  # reads ANTHROPIC_API_KEY from your environment
MODEL = "claude-haiku-5-5"      # fast and cheap; check docs.claude.com for current names

SYSTEM = (
    "You are a crop advisor for farmers in Tamil Nadu. Use the tools to look up facts "
    "before answering; do not guess planting dates, soil suitability or weather. "
    "If the crop or district is missing, ask for it. Keep answers short and practical."
)


def run_agent(question: str, max_steps: int = 6) -> str:
    messages = [{"role": "user", "content": question}]

    for _ in range(max_steps):
        resp = client.messages.create(
            model=MODEL,
            max_tokens=800,
            system=SYSTEM,
            tools=TOOL_SCHEMAS,
            messages=messages,
        )
        messages.append({"role": "assistant", "content": resp.content})

        # The model answered without needing a tool: we are done
        if resp.stop_reason != "tool_use":
            return "".join(b.text for b in resp.content if b.type == "text")

        # Otherwise run each requested tool and send the results back
        results = []
        for block in resp.content:
            if block.type == "tool_use":
                print(f"  [tool] {block.name}({block.input})")
                try:
                    output = TOOL_FUNCTIONS[block.name](**block.input)
                except Exception as e:
                    output = f"Error: {e}"
                results.append({
                    "type": "tool_result",
                    "tool_use_id": block.id,
                    "content": str(output),
                })
        messages.append({"role": "user", "content": results})

    return "Sorry, I could not finish that request. Please ask again more simply."


if __name__ == "__main__":
    while True:
        q = input("\nFarmer question (blank to quit): ").strip()
        if not q:
            break
        print("\n" + run_agent(q))
