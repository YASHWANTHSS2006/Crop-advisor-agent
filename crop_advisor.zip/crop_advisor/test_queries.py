from agent import run_agent

# (question, word the answer must contain, lowercase)
TESTS = [
    ("What months should I plant maize?", "jun"),
    ("Is sandy soil good for groundnut?", "suitable"),
    ("Is black soil good for cotton?", "suitable"),
    ("Is clay soil good for groundnut?", "not ideal"),
    ("What is the water need for rice?", "high"),
    ("Will it rain in Coimbatore in the next 3 days?", "rain"),
    ("What soil is best for tomato?", "loam"),
    ("Can I plant millet in red soil?", "suitable"),
    ("What is the water need for millet?", "low"),
    ("When should I plant sugarcane?", "jan"),
]

passed = 0
for question, expected in TESTS:
    answer = run_agent(question)
    ok = expected in answer.lower()
    passed += ok
    print(f"{'PASS' if ok else 'FAIL'} | {question}")

print(f"\nAccuracy: {passed}/{len(TESTS)} = {100 * passed / len(TESTS):.0f}%")
