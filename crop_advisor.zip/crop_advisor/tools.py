import csv
from pathlib import Path

import requests

DATA = Path(__file__).parent / "data" / "crops.csv"

# Approximate district coordinates (latitude, longitude)
DISTRICTS = {
    "chennai": (13.08, 80.27),
    "coimbatore": (11.00, 76.96),
    "madurai": (9.92, 78.12),
    "erode": (11.34, 77.72),
    "salem": (11.66, 78.15),
}


def _load_crops():
    with open(DATA, newline="", encoding="utf-8") as f:
        return list(csv.DictReader(f))


def _find_crop(crop):
    for row in _load_crops():
        if row["crop"].lower() == crop.strip().lower():
            return row
    return None


def get_crop_info(crop: str) -> str:
    row = _find_crop(crop)
    if row is None:
        known = ", ".join(r["crop"] for r in _load_crops())
        return f"No data for crop '{crop}'. Known crops: {known}"
    return (f"{row['crop']}: plant in {row['planting_months']}; "
            f"suitable soils: {row['soil_types']}; water need: {row['water_need']}; "
            f"notes: {row['notes'] or 'none'}")


def check_soil(crop: str, soil_type: str) -> str:
    row = _find_crop(crop)
    if row is None:
        return f"No data for crop '{crop}'."
    if soil_type.strip().lower() in row["soil_types"].lower():
        return f"{soil_type} is suitable for {row['crop']}."
    return f"{soil_type} is not ideal for {row['crop']}. Suitable soils: {row['soil_types']}."


def get_weather(district: str) -> str:
    key = district.strip().lower()
    if key not in DISTRICTS:
        return f"Unknown district. Supported: {', '.join(DISTRICTS)}."
    lat, lon = DISTRICTS[key]
    r = requests.get(
        "https://api.open-meteo.com/v1/forecast",
        params={
            "latitude": lat,
            "longitude": lon,
            "daily": "precipitation_sum,temperature_2m_max",
            "forecast_days": 3,
            "timezone": "Asia/Kolkata",
        },
        timeout=10,
    )
    r.raise_for_status()
    d = r.json()["daily"]
    lines = [f"{day}: rain {p} mm, max {t} °C"
             for day, p, t in zip(d["time"], d["precipitation_sum"], d["temperature_2m_max"])]
    return f"3-day forecast for {district.title()}: " + "; ".join(lines)


# Lookup used by the agent loop
TOOL_FUNCTIONS = {
    "get_crop_info": get_crop_info,
    "check_soil": check_soil,
    "get_weather": get_weather,
}

# Tool descriptions the LLM reads to decide what to call
TOOL_SCHEMAS = [
    {
        "name": "get_crop_info",
        "description": "Get planting months, suitable soils, water need and notes for a crop.",
        "input_schema": {
            "type": "object",
            "properties": {"crop": {"type": "string", "description": "Crop name, e.g. Rice"}},
            "required": ["crop"],
        },
    },
    {
        "name": "check_soil",
        "description": "Check whether a soil type is suitable for a crop.",
        "input_schema": {
            "type": "object",
            "properties": {
                "crop": {"type": "string"},
                "soil_type": {"type": "string", "description": "e.g. sandy, loam, black soil"},
            },
            "required": ["crop", "soil_type"],
        },
    },
    {
        "name": "get_weather",
        "description": "Get a 3-day rain and max temperature forecast for a Tamil Nadu district.",
        "input_schema": {
            "type": "object",
            "properties": {"district": {"type": "string", "description": "e.g. Coimbatore"}},
            "required": ["district"],
        },
    },
]
