# Crop Advisor Agent

A Python tool-calling agent that answers farmer questions about crops in Tamil Nadu. The LLM decides which tool to call: crop information, soil suitability, or a 3-day weather forecast. It then combines the results into a short recommendation.

## Tools
- `get_crop_info(crop)`: planting months, suitable soils, water need
- `check_soil(crop, soil_type)`: whether a soil suits a crop
- `get_weather(district)`: 3-day rain and temperature forecast (Open-Meteo, no API key needed)

## Setup
```bash
pip install -r requirements.txt
export ANTHROPIC_API_KEY="your-key-here"
```

## Run
```bash
python agent.py          # interactive chat
python test_queries.py   # runs 10 test questions and prints accuracy
```

## Data
Crop data is in `data/crops.csv`. Source: [add your source here, e.g. Tamil Nadu Agricultural University].

## Results
Accuracy on 10 test queries: [X]%

## Limitations
- Crop data covers 8 crops only.
- Weather is available for 5 districts only.
- Advice is for guidance; check with your local agriculture office before major decisions.
